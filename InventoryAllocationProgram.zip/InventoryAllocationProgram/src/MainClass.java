
/*Comment start
 
 *This class contains the main method for this program
 
 *Tasks performed in this class include the following:
 
 		*	Get the input (String) from the user
 		*	Pass the obtained input to "Inventory Allocator class" - to pre process the string data and calculate the best probability
 		*	Finally print the obtained output String that contains the orders which can be shipped.
 
comment ends*/

import java.util.Scanner;

public class MainClass 
{
		/* This function gets the input string from the user, passes the input to InventoryAllocator Class and gets the processed Output String to be displayed.
		and finally it calls the function that cleans all the static variables and set its default value*/
		public static void main(String[] args) 
		{
				Scanner input = new Scanner(System.in);
				
				// string variable that is used to get input from the user.
				String inputString; 
				
				// string variable that obtains the output string to be displayed.
				String outputString;
				
				System.out.println("Please enter the input in the format below:");
				System.out.println("{ Item1: count, Item2: count,... }, [{ name: name_of_the_warehouse, inventory: { Item1: Available_count, Item2: Available_count,... } }, { name: name_of_the_warehouse, inventory: { Item1: Available_count, Item2: Available_count,... } }]");
				System.out.println(" Input: ");
				inputString  = input.nextLine();
				
				InventoryAllocator inventoryAllocator  = new InventoryAllocator();		
				outputString  = InventoryAllocator.checkInputFormat(inputString);		
				printOutputString(outputString);	
				InventoryAllocator.cleanAllStaticVariables();
		}

		//This function prints the output String to the user.
		private static void printOutputString(String outputString) 
		{
				System.out.println("Output:");
				System.out.println(outputString);
		}

}


